/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ipl.sis.ficha1_redone;

import java.time.LocalDate;
import java.time.Period;


/**
 *
 * @author Bruno
 */
public class Pessoa  {
    public String Nome;
    public LocalDate DataDeNascimento;
    private String Morada;

    public Pessoa(String nome, LocalDate DataDeNascimento, String Morada) {
        this.Nome = nome;
        this.DataDeNascimento = DataDeNascimento;
        this.Morada = Morada;
    }
    
    
       public int getIdade()
   {       
        LocalDate agora;
        agora = LocalDate.now();
        int anos = Period.between(DataDeNascimento, agora).getYears();
        
        return anos;
   }
   
  @Override 
  public String toString()
  {
        return this.Nome + " (" + this.getIdade() + " anos)";
  }
  
  
}
