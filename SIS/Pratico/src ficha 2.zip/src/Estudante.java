
import java.util.ArrayList;
import org.codehaus.jackson.annotate.JsonIgnore;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Bruno
 */
public class Estudante {

    private int numeroEstudante;
    private String nome;
    private int idade;
    private ArrayList<String> unidades = new ArrayList<>();
    
    public int getNumeroEstudante() {
        return numeroEstudante;
    }

    public String getNome() {
        return nome;
    }

    //@JsonIgnore
    public int getIdade() {
        return idade;
    }
    
    public ArrayList<String> getUnidades() {
        return unidades;
    }

    
    public Estudante(){};
    
    public Estudante(int numeroEstudante, String nome, int idade) {
        this.numeroEstudante = numeroEstudante;
        this.nome = nome;
        this.idade = idade;
    }

    public void addUnidade(String unidade){
        unidades.add(unidade);
    }
    
    @Override
    public String toString() {
        return 
                "Estudante{" 
                + "numeroEstudante=" + numeroEstudante
                  + " ; nome=" + nome
                  + " ; unidades=" + unidades
                ;
    }
}
